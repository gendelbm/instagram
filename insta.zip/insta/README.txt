	# Instagram Like Bot That Drive Organic Followers

Remember Instagram has own Limitation for Likes per Day. You can like only 1000 photos per day! So in you hashtag list you need to have only 8-9 hashtags and than stop bot.


1. First of all we need to install Python3 and all libs that we need to running our Bot

apt-get install python3

apt-get install python3-pip

pip3 install selenium



Download geckodriver for firefox

https://github.com/mozilla/geckodriver/releases

Move it to folder

/usr/bin/


2. Now we need to change hashtag file to get followers in your niche


3. Run Instagram Bot

python3 insta_bot.py


This Bot watching on instagram photos and like them. Leave the bot working and it will do all job for you. In such way you drive organic followers for your profile.
